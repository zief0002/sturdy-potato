
library(tidyverse)

social <- read.csv("social.csv")

convert_units <- function(x) {
  
  if (class(x) == "numeric") return(x)
  
  # named vector of scalings (you can add to this)
  unit_scale <- c("k" = 1e3, "m" = 1e6)
  
  # clean up some potential nuisances with the input
  x_str <- gsub(",", "", trimws(tolower(as.character(x))))
  
  # extract out the letters
  unit_char <- gsub("[^a-z]", "", x_str)
  
  # extract out the numbers and convert to numeric
  x_num <- as.numeric(gsub("[a-z]", "", x_str), "", x_str)
  
  # develop a vector of multipliers
  multiplier <- unit_scale[match(unit_char, names(unit_scale))]
  multiplier[is.na(multiplier)] <- 1
  
  # multiply
  x_num * multiplier
}
social$sub2 <- convert_units(social$sub)
social$views2 <- convert_units(social$views)
social$likes2 <- convert_units(social$likes)
social$coments2 <- convert_units(social$comments)

head(social)
write.csv(social, "social2.csv")

socialMedia <- read.csv()
head(socialMedia)
ggplot(data = socialMedia, aes(x = likes, y = sub)) + geom_point() 
ggplot(data = socialMedia, aes(x = comments, y = sub)) + geom_point() 
ggplot(data = socialMedia, aes(x = views, y = likes)) + geom_point() 
sub <- sample_n(socialMedia, size = 50, replace = FALSE)

ggplot(data = sub, aes(x = likes, y = sub)) + geom_point() 
ggplot(data = sub, aes(x = comments, y = sub)) + geom_point() 
ggplot(data = sub, aes(x = views, y = likes)) + geom_point() 

write.csv(sub, "social50.csv")
